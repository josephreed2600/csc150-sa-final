package controllers;

public interface IController {
    public void run();
}
